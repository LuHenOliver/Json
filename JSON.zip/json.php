<?php

$arquivo = "dados.json";
$dados[] = array ();

$dados["cpf"] = "32145698777";
$dados["nome"]= "João da Silva";
$dados["email"]= "joao@silva.com.br";
$dados["senha"]= md5("senha");

if( file_exists($arquivo) ){
    $dadosLidos = file_get_contents($arquivo);
    $existente  = json_decode($dadosLidos, true);
    echo "Nome da pessoa nos dados lidos: " . $existente["nome"];

    exit();

    
}
else 
{
    $json = json_encode($dados); 
    file_put_contents($arquivo, $json); 
    echo "<h2> $json </h2>";
    header("location: form.html");
}


?>